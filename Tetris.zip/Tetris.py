import pygame, sys
from pygame.locals import *
import base64
from TetrisFont import Tetrisfont
from RGBTitle import RGBTitle
from TetrisLogo import logo
from BSOD import Cancer
from BSODFont import Death


# set up pygame
pygame.init()
windowSurface = pygame.display.set_mode((800, 600), 0, 32)
pygame.display.set_caption('Tetris')

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

with open('Tetrisfont.ttf', 'wb') as imagef:
    imagef.write(base64.b64decode(Tetrisfont))
Font = pygame.font.Font('Tetrisfont.ttf', 48)
with open('Logo.png', 'wb') as imagef:
    imagef.write(base64.b64decode(logo))
with open('BSODFont.ttf', 'wb') as imagef:
    imagef.write(base64.b64decode(Death))
BSODFont = pygame.font.Font('BSODFont.ttf', 48)
with open('BSOD.png', 'wb') as imagef:
    imagef.write(base64.b64decode(Cancer))

title = RGBTitle(Font, "Tetris", (200, 550), [WHITE, RED, GREEN, BLUE, GREEN, RED])
a = pygame.image.load('Logo.png')
pygame.display.set_icon(a)
score = 0
grid = []

for x in range(11):
    grid.append([False] * 11)

grid[5][5] = True

print(grid)
clock = pygame.time.Clock()

while True:
    
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                pygame.quit()
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
    deltaTime = clock.tick()
    
    windowSurface.fill(BLACK)
    pygame.draw.rect(windowSurface,WHITE,(550,0, 250, 600), 2)
    for x in range(0,600,50):
        pygame.draw.line(windowSurface,WHITE,(1,x),(550,x), 2)
        pygame.draw.line(windowSurface,WHITE,(x,1),(x,550), 2)


    title.render(windowSurface)
    for x in range(len(grid)):
        for y in range(len(grid[0])):
            if grid[x][y] == True:
                # draw a block in the right place
                # render_rect(X * 50, Y * 50, )
                pygame.draw.rect(windowSurface, RED, (x*50+2, y*50+2, 48, 48))
    pygame.display.update()

